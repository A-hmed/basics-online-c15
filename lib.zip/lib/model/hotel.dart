class HotelDM {
  String image;
  String name;

  HotelDM({required this.name, required this.image});
}